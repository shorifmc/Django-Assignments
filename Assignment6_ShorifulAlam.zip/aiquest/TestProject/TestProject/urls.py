from django.contrib import admin
from django.urls import path, include
from TestApp1 import views as ta1 # we can run this project commentig this line


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', ta1.Home), # we can run this project commentig this line
    path('dl/', ta1.deep_learning), # we can run this project commentig this line
    #path('', include('TestApp1.urls')),
    path('app2/', include('app2.urls')),
    path('app3/', include('app3.urls')),

]
