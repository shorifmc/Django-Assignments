from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.


def FirstBlog(request):
    return render(request,'blogs.html')

def MyCalculator(request):
    return render(request,'calculator.html')

