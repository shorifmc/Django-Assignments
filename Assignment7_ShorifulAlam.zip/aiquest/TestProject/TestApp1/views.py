from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def Home(request):
    return HttpResponse('My name is Shoriful Alam')

def deep_learning(request):
    return HttpResponse('Weklcome to deep_learning')
