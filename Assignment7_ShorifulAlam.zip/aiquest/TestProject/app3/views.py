from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.


def FirstBlog(request):
    return render(request,'app3/blogs.html', {'fb':5})


def SecondBlog(request):
    #return render(request,'app3/blogs.html', {'fb':5})
    var1 = '60 days of django'
    var2 = 'MongoDB course'
    var3 = 'ML course'
    var4 = 'DL course'
    dtl = {'v1':var1, 'v2':var2, 'v3':var3, 'v4':var4}
    return render(request,'app3/blogs.html', dtl)


def MyCalculator(request):
    return render(request,'app3/calculator.html')


def inheritance_function(request):
    return render(request,'app3/inheritance_exam.html')




