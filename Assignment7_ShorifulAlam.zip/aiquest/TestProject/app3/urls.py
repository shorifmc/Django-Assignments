from django.urls import path
from . import views

urlpatterns = [
    path('', views.FirstBlog),
    path('2bg', views.SecondBlog),
    path('cl/', views.MyCalculator),
    path('inh/', views.inheritance_function),

      
]