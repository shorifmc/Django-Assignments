from django.urls import path
from . import views

urlpatterns = [
    path('', views.app2function),
    path('bd/', views.BidData),
   
]
