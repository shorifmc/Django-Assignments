from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.


def app2function(request):
    return HttpResponse('Welcome! This is my second app first function')

def BidData(request):
    return HttpResponse('There are Bid Data Course available here!')